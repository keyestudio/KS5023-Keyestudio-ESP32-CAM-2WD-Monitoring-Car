/*
  项目名称: 呼吸灯
  作者: Keyestudio
  描述: 介绍如何控制LED灯的亮度。
*/
int ledPin = 4;  //定义变量ledPin为GPIO4脚
void setup() {
  // put your setup code here, to run once:
  pinMode(ledPin, OUTPUT);  //设置GPIO4脚为输出模式
}

void loop() {
  // put your main code here, to run repeatedly:
  for (int i = 0; i <= 255; i++) {  //循环将i的值从0加到255
    analogWrite(ledPin, i); //GPIO4以PWM形式输出，并且设置PWM值为i
    delay(10);  //延时10ms
  }
  for (int i = 255; i >= 0; i--) {  //循环将i的值从255减到0
    analogWrite(ledPin, i); //GPIO4以PWM形式输出，并且设置PWM值为i
    delay(10);
  }
}
