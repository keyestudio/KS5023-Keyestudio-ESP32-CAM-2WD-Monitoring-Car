/*
  项目名称: LED控制
  作者: Keyestudio
  描述: 介绍如何控制LED灯的亮灭。
*/
int ledPin = 4; //定义变量ledPin为GPIO4脚
void setup() {
  // put your setup code here, to run once:
  pinMode(ledPin,OUTPUT); //设置GPIO4脚为输出模式
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(ledPin,HIGH);  //控制GPIO4脚输出高电平
  delay(500); //延时500ms
  digitalWrite(ledPin,LOW); //控制GPIO4输出低电平
  delay(500); //延时500ms
}
