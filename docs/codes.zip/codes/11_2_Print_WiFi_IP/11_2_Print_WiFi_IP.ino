/*
  项目名称: 打印WiFi IP
  作者: Keyestudio
  描述: 介绍如何使用ESP32连接WiFi并打印ESP32的ip地址
*/
//导入wifi库文件
#include <WiFi.h>

//请将“your_SSID”修改成你的wifi 名称
const char* ssid = "your_SSID";
//请将“your_PASSWORD”修改成你的wifi密码
const char* password = "your_PASSWORD";

void setup() {
  Serial.begin(9600);
  //初始化Wifi
  WiFi.begin(ssid, password);
  //寻找wifi，未连接成功，则一直处于连接中状态，while循环
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  //连接成功，打印 IP 地址
  Serial.println("Connected to WiFi");
  Serial.println(WiFi.localIP());
}

void loop() {
}