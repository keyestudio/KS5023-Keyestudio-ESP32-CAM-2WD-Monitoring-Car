/*
  项目名称: 网页显示
  作者: Keyestudio
  描述: 介绍如何使用ESP32连接WiFi并且搭建网页显示“Hello World”
*/
#include <WiFi.h>
#include "esp_camera.h"
#include "esp_http_server.h"

// Replace with your network credentials
const char *ssid = "your_SSID";          // 改成你的Wi-Fi名称
const char *password = "your_PASSWORD";  // 改成你的Wi-Fi密码

httpd_handle_t camera_httpd = NULL;  // HTTP服务器句柄，用于启动服务器

// 简化后的HTML页面，仅包含标题的内容
static const char PROGMEM INDEX_HTML[] = R"rawliteral(
<html>
  <head>
  <body>
    <h1>Hello World</h1>  <!-- 页面正文中的标题文本 -->
  </body>
</html>
)rawliteral";

// 处理根URL（"/"）请求的回调函数
static esp_err_t index_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html");  // 设置响应的内容类型为HTML
  return httpd_resp_send(req, (const char *)INDEX_HTML, strlen(INDEX_HTML));  // 发送包含标题的HTML响应
}

// 启动HTTP服务器并注册处理根路径（"/"）的请求
void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();  // 使用默认的HTTP配置
  config.server_port = 80;  // 设置HTTP服务器监听端口为80

  // 配置根路径（"/"）的请求处理
  httpd_uri_t index_uri = {
    .uri = "/",               // 设置请求的URI路径为"/"
    .method = HTTP_GET,       // 设置请求方法为GET
    .handler = index_handler, // 设置处理请求的回调函数
    .user_ctx = NULL          // 没有额外的上下文数据
  };

  // 启动HTTP服务器并注册根路径的请求处理
  if (httpd_start(&camera_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(camera_httpd, &index_uri);  // 注册URI处理程序
  }
}

void setup() {
  Serial.begin(115200);  // 启动串口，设置波特率为115200

  // 连接Wi-Fi网络
  WiFi.begin(ssid, password);  // 启动Wi-Fi连接
  while (WiFi.status() != WL_CONNECTED) {  // 如果未连接Wi-Fi，则一直等待
    delay(500);  // 每500ms打印一次
    Serial.print(".");  // 在串口监视器上打印点，以指示正在尝试连接
  }
  Serial.println("");  // 换行
  Serial.println("WiFi connected");  // Wi-Fi连接成功时打印信息
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());   //打印IP地址
  // 启动HTTP服务器
  startCameraServer();  // 启动HTTP服务器并注册处理程序
}

void loop() {
  // 主循环为空，因为HTTP服务器在后台处理请求
}
